﻿function initializeSlider(slideIdentifier) {
    // slider widget setup
    $(slideIdentifier).slick({
        infinate: true,
        autoPlay: true,
        dots: false
    });
}
