﻿function PagingTemplate(totalPage, currentPage) {
    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    var startPage;
    if (currentPage == 1) startPage = 1;
    else startPage = currentPage - 1;

    for (var i = startPage; i <= totalPage; i++) {
        PageNumberArray[0] = startPage;
        if (totalPage != currentPage - 1 && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };

    PageNumberArray = PageNumberArray.slice(0, 3);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    template = template + '<li class="page-item"><a style="cursor:pointer;" class="page-link" aria-label="Previous" onclick="GetPageData(' + FirstPage + ')"><span aria-hidden="true">&laquo;</span></a></li>';

    for (var i = 0; i < PageNumberArray.length; i++) {
        if (PageNumberArray[i] == currentPage) {
            template = template + '<li class="page-item active"><a style="cursor:pointer;" class="page-link" onclick="GetPageData(' + PageNumberArray[i] + ')">' + PageNumberArray[i] + '</a></li>';
        } else {
            template = template + '<li class="page-item"><a style="cursor:pointer;" class="page-link" onclick="GetPageData(' + PageNumberArray[i] + ')">' + PageNumberArray[i] + '</a></li>';
        }
    }

    template = template + '<li class="page-item"><a style="cursor:pointer;" class="page-link" aria-label="Next" onclick="GetPageData(' + LastPage + ')"><span aria-hidden="true">&raquo;</span></a></li>';
    $("#lum-jobs-pagination").append(template);
}