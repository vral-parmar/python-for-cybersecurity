<?php

$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email= $_POST['email'];   
    $department = $_POST['department'];
    $location = $_POST['locations'];
    $comments = $_POST['comments'];

    $sql = "INSERT INTO Data (firstname, lastname, email, department, location, comments) VALUES ('$firstname', '$lastname', '$email', '$department','$location','$comments')";

    if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
    header("Refresh:3; url=https://lummustech.com");
    } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);

?>