﻿(function($) {
    
    var mediaReleaseWidget = {
        options: {
            pageUrl: '',
            viewData: null,
            currentPage: 1,
            totalPages: 1
        },
        elements: {
            //...
        },
        _create: function () {
            var I = this;
            //debugger;

            I.element.on('click', '.btn-next-page', function(evt){
                evt.preventDefault();
                I.loadPage(I.option('currentPage') + 1);
            });
        },

        loadPage: function(pageNum) {
            var I = this,
                viewData = I.option('viewData');

            $.get(I.option('pageUrl'), {
                pageNumber: pageNum,
                pageSize: viewData.PageSize,
                path: viewData.NewsLocationPath,
                orderBy: viewData.OrderBy
            }).then(function(moreItems){
                var $itemsWrap = I.element.find('.index-items');
                //$itemsWrap.html(content);
                //$.scrollTo($itemsWrap);
                $itemsWrap.append(moreItems);
                I.option('currentPage', pageNum);

                if(pageNum >= I.option('totalPages')) {
                    I.element.find('.btn-next-page').fadeOut();
                }
            });
        }
    };

    $.widget('lummus.mediaReleaseWidget', mediaReleaseWidget);
    
})(jQuery);