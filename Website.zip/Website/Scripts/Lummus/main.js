﻿if (/Trident\/|MSIE/.test(window.navigator.userAgent)) {
    document.body.classList.add('IE11');
}

//------------------------------------------------------------------
// Global doc ready init
//------------------------------------------------------------------
$(document).ready(function () {

    // Init nav
    $('ul.nav li.dropdown').hover(function () {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(1);
    }, function () {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(1);
    });

    // Init sliders
    initializeSlider('.slider');

    // Make entire divs clickable
    $(document).on('click', '[data-href]', function (evt) {
        var fakeLink = $('<a>', {
            href: $(this).attr('data-href')
        });
        window.location = fakeLink.get(0).href;
    });

    // Add some Animate On Scroll properties automatically
    $('.lum-section .lum-card-list').each(function(i, el){
        $(el).attr('data-aos', 'zoom-in')
            .attr('data-aos-delay', i * 100);
    });

    // Add form field classes for CSS specificity
    $('.form-field').formFieldWrapAttrHooks();

    defer(function(){
        // Init Animate On Scroll
        AOS.init({
            // Settings that can be overridden on per-element basis, by `data-aos-*` attributes:
            offset: 120, // offset (in px) from the original trigger point
            delay: 0, // values from 0 to 3000, with step 50ms
            duration: 500, // values from 0 to 3000, with step 50ms
            easing: 'ease-in-out', // default easing for AOS animations
            once: true, // whether animation should happen only once - while scrolling down
            mirror: false, // whether elements should animate out while scrolling past them
            anchorPlacement: 'top-bottom', // defines which position of the element regarding to window should trigger the animation
        });
    }, 500);
});


$.fn.formFieldWrapAttrHooks = function(){    
    this.each(function(i, el){
        var $el = $(el),
        $input = $el.find(':input').first();
        if($input.length){
            $el.attr('data-field-name', $input.attr('name'));
            $el.attr('data-field-id', $input.attr('id'));
            $el.attr('data-field-type', ($input.attr('type') || $input.get(0).tagName).toLowerCase());
        }
    });    
};

